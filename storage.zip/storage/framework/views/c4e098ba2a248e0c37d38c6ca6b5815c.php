

<?php $__env->startSection('title', 'Technical'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gx-0">
    <div class="col-2 sidebar mh-100 bg-dark text-white rounded-end shadow-sm">
        <ul class="list-group sidebar-list fs-5">
            <a href="<?php echo e(route('dashboard.index')); ?>" class="text-decoration-none">
                <li class="list-item fw-bold p-3 hover:bg-primary rounded">
                    <i class="fa-solid fa-tachometer-alt"></i> Dashboard
                </li>
            </a>
            <a href="<?php echo e(route('technical.show')); ?>" class="text-decoration-none">
                <li class="list-item fw-bold p-3 hover:bg-primary rounded">
                    <i class="fa-solid fa-box-open"></i> View Applications
                </li>
            </a>
            <a href="<?php echo e(route('client.show')); ?>" class="text-decoration-none">
                <li class="list-item fw-bold p-3 hover:bg-primary rounded">
                    <i class="fa-solid fa-chart-pie"></i> Reports
                </li>
            </a>
        </ul>
    </div>

    <div class="col-10">
        <div class="table-responsive">
            <table class="table table-hover text-center mx-auto">
                <thead class="bg-primary text-white">
                    <tr>
                        <th>ID No.</th>
                        <th>Full Name</th>
                        <th>Application No.</th>
                        <th>Application Type</th>
                        <th>Denomination</th>
                        <th>Chassis No.</th>
                        <th>Motor No.</th>
                        <th>Plate No.</th>
                        <th>Status</th>
                        <th>Remarks</th>
                        <th>Fees</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $all_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($app->id); ?></td>
                        <td><?php echo e($app->user->first_name); ?> <?php echo e($app->user->last_name); ?></td>
                        <td>
                            <button type="button" data-bs-toggle="modal" data-bs-target="#app-<?php echo e($app->id); ?>" class="btn btn-link text-primary">
                                <?php echo e($app->app_number); ?>

                            </button>
                        </td>
                        <td><?php echo e($app->type->name); ?></td>
                        <td><?php echo e($app->deno->name); ?></td>
                        <td><?php echo e($app->chassis_number); ?></td>
                        <td><?php echo e($app->motor_number); ?></td>
                        <td><?php echo e($app->plate_number); ?></td>
                        <form action="<?php echo e(route('technical.update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="application_id" value="<?php echo e($app->id); ?>">
                            <td class="align-middle">
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="status[<?php echo e($app->id); ?>]" id="verified-<?php echo e($app->id); ?>" value="1" class="form-check-input" <?php echo e($app->status == 1 ? 'checked' : ''); ?>>
                                    <label for="verified-<?php echo e($app->id); ?>" class="form-check-label text-success fst-italic">Verified</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="status[<?php echo e($app->id); ?>]" id="pending-<?php echo e($app->id); ?>" value="2" class="form-check-input" <?php echo e($app->status == 2 ? 'checked' : ''); ?>>
                                    <label for="pending-<?php echo e($app->id); ?>" class="form-check-label text-warning fst-italic">Pending</label>
                                </div>
                                <?php $__errorArgs = ['status[<?php echo e($app->id); ?>]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger small"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <textarea name="remarks[<?php echo e($app->id); ?>]" id="remarks" cols="3" rows="3" class="form-control"><?php echo e($app->remarks); ?></textarea>
                                <?php $__errorArgs = ['remarks[<?php echo e($app->id); ?>]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger small"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('technical.fees', $app->id)); ?>" class="btn btn-outline-primary btn-sm">Fees</a>
                                <a href="<?php echo e(route('technical.showfees', $app->id)); ?>" class="btn btn-outline-primary btn-sm">Show Fees</a>
                            </td>
                            <td><?php echo e($app->remarks); ?></td>
                        </form>
                    </tr>
                    <?php echo $__env->make('users.technical.modals.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="12" class="text-center">
                            <p class="text-muted fst-italic fs-2">No results found.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td colspan="11"></td>
                        <td class="text-center">
                            <button type="submit" class="btn btn-danger">Submit</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    /* Remove borders of the table */
    .table, .table th, .table td {
        border: none !important;
    }

    /* Center all text inside the table */
    .table th, .table td {
        text-align: center;
        vertical-align: middle;
        horizontal-align: middle;
    }

    /* Style the table to center it on the page */
    .table-responsive {
        margin: 0 auto;
    }

    /* Global font style */
    body, .table, .sidebar-list, .form-check-label, .btn, .modal-body, .modal-header, .modal-footer {
        font-family: 'Arial', 'sans-serif';
    }

    /* Styling for the modal */
    .modal-body {
        color: black !important;
    }
    .modal-header, .modal-footer {
        color: black !important;
    }

    /* Style the form checkboxes */
    .form-check-inline {
        margin-right: 10px;
    }

    /* Style the buttons for Fees and Actions */
    .btn-outline-primary {
        margin-top: 5px;
        margin-bottom: 5px;
    }

    /* Add some spacing to the table rows for better readability */
    .table tr td {
        padding: 15px;
    }

    /* Add some spacing for the Submit button */
    .btn-danger {
        padding: 10px 20px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-laravel-mit\online-app\resources\views/users/technical/show.blade.php ENDPATH**/ ?>