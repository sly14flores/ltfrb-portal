 

<?php $__env->startSection('title', 'Technical'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gx-0">
    <!-- Sidebar -->
    <div class="card col-2 card-background h-100 shadow-lg rounded">
        <ul class="list-group sidebar-list fs-5">
            <a href="<?php echo e(route('dashboard.index')); ?>" class="text-decoration-none text-white mb-2">
                <li class="fw-bold d-flex align-items-center p-3 hover-bg-primary rounded">
                    <i class="fa-solid fa-chart-line me-2"></i> Dashboard
                </li>
            </a>
            <a href="<?php echo e(route('technical.show')); ?>" class="text-decoration-none text-white mb-2">
                <li class="fw-bold d-flex align-items-center p-3 hover-bg-primary rounded">
                    <i class="fa-solid fa-box-open me-2"></i> View Applications
                </li>
            </a>
            <a href="#" class="text-decoration-none text-white mb-2">
                <li class="fw-bold d-flex align-items-center p-3 hover-bg-primary rounded">
                    <i class="fa-regular fa-envelope me-2"></i> Reports
                </li>
            </a>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="col-10 w-75 mx-auto">
        <div class="row mt-5">
            <div class="col bg-white p-4 rounded shadow-sm">
                <h1 class="h3 mt-3">Full Name: <?php echo e($application->user->first_name); ?> <?php echo e($application->user->last_name); ?></h1>
                <p class="text-muted">Application Number: <?php echo e($application->app_number); ?></p>
                <hr>
                <h3>Fees</h3>
                <p class="text-muted">Penalties and associated fees.</p>

                <form action="<?php echo e(route('technical.saveFees')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="app_id" value="<?php echo e($application->id); ?>">

                    <!-- Fees Table -->
                    <table class="table table-bordered table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col">Fee Description</th>
                                <th scope="col">Amount</th>
                                <th scope="col">Apply Fee</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $all_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($fee->name); ?></td>
                                <td><?php echo e($fee->id > 6 ? '' : '₱'); ?> <?php echo e($fee->amount); ?></td>
                                <td>
                                    <?php if($fee->id < 7): ?>
                                    <input type="checkbox" name="fees[<?php echo e($fee->id); ?>]" id="<?php echo e($fee->name); ?>" class="form-check-input" value=<?php echo e($fee->id); ?>>
                                    <?php else: ?>
                                    <input type="number" name="custome_fees[<?php echo e($fee->id); ?>]" id="<?php echo e($fee->name); ?>" class="form-control" placeholder="₱0.00">
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <!-- Additional Fees (Surcharges, Late Confirmation, etc.) -->
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="surcharges" class="form-label small">Surcharges</label>
                            <input type="number" name="surcharges" id="surcharges" value="<?php echo e(old('surcharges', $application->surcharges)); ?>" class="form-control">
                            <?php $__errorArgs = ['surcharges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger small"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6">
                            <label for="late_confirmation" class="form-label small">Late Confirmation</label>
                            <input type="number" name="late_confirmation" id="late_confirmation" value="<?php echo e(old('late_confirmation', $application->late_confirmation)); ?>" class="form-control">
                            <?php $__errorArgs = ['late_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger small"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="penalties" class="form-label small">Penalties</label>
                            <input type="number" name="penalties" id="penalties" value="<?php echo e(old('penalties', $application->penalties)); ?>" class="form-control">
                            <?php $__errorArgs = ['penalties'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger small"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6">
                            <label for="others" class="form-label small">Others</label>
                            <input type="number" name="others" id="others" value="<?php echo e(old('others', $application->others)); ?>" class="form-control">
                            <?php $__errorArgs = ['others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger small"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="d-flex justify-content-between align-items-center my-3">
                        <button class="btn btn-primary ms-auto" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-appp\resources\views/users/technical/payfees.blade.php ENDPATH**/ ?>