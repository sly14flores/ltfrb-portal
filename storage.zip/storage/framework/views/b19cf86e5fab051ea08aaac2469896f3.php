

<?php $__env->startSection('title', 'Admin: Users'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-2 admin-dashboard-list mh-100">
            <ul class="admin-list fs-5 list-group">
                <a href="<?php echo e(route('admin.users')); ?>" class="text-decoration-none text-white mb-1">
                    <li class="fw-bold">
                        <i class="fa-solid fa-chart-line"></i> Manage Users
                    </li>
                </a>
                <a href="<?php echo e(route('admin.denominations')); ?>" class="text-decoration-none text-white mb-1">
                    <li class="fw-bold">
                        <i class="fa-solid fa-chart-line"></i> Manage Denomination
                    </li>
                </a>
                <a href="#" class="text-decoration-none text-white">
                    <li class=" fw-bold text-white">
                        <i class="fa-regular fa-envelope"></i> Manage Application Type
                    </li>
                </a>
            </ul>
        </div> 

        <div class="col-10">
            <table class="table table-hover align-middle ms-1 mt-2">
                <thead>
                    <tr>
                        <th></th>
                        <th>Full Name</th>
                        <th>Email Address</th>
                        <th>Role</th>
                        <th>Date Registered</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($user->avatar): ?>
                                    <img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" class="img-thumbnail image-sm">
                                <?php else: ?>
                                    <i class="fas fa-circle-user text-dark icon-sm"></i>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if($user->role_id === $admin): ?>
                                    Admin
                                <?php elseif($user->role_id === $tech): ?>
                                    Technical
                                <?php elseif($user->role_id === $record): ?>
                                    Record
                                <?php elseif($user->role_id === $client): ?>
                                    Client
                                <?php else: ?>
                                    Staff
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->created_at); ?></td>
                          
                            <td>
                                <?php if(Auth::user()->id !== $user->id): ?>
                                     
                                    <button class="btn btn-outline-warning btn-sm me-2" data-bs-toggle="modal" data-bs-target="#edit-user-<?php echo e($user->id); ?>" title="Edit">
                                        <i class="fa-solid fa-pen"></i>
                                    </button>

                                    
                                    <button class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#delete-user-<?php echo e($user->id); ?>" title="Delete">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>       
                                <?php endif; ?>
                                            
                            </td>
                        </tr>
                        <?php echo $__env->make('admin.users.modals.action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-laravel-mit\online-app\resources\views/admin/users/index.blade.php ENDPATH**/ ?>