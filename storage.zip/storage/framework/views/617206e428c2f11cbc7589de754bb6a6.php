

<?php $__env->startSection('title', 'Client'); ?>

<?php $__env->startSection('content'); ?>

<div class="row gx-0">
    <!-- Sidebar -->
    <div class="card col-2 card-background h-100 shadow-lg rounded">
        <ul class="list-group sidebar-list fs-5">
            <?php if(Auth::user()->role_id === $client): ?>
                <a href="<?php echo e(route('client.create')); ?>" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-solid fa-file-circle-plus"></i> File Application
                    </li>
                </a>
                <a href="<?php echo e(route('client.show')); ?>" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-regular fa-folder-open"></i> View Applications
                    </li>
                </a>
            <?php elseif(Auth::user()->role_id === $tech): ?>
                <a href="<?php echo e(route('dashboard.index')); ?>" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-solid fa-tachometer-alt"></i> Dashboard
                    </li>
                </a>
                <a href="<?php echo e(route('technical.show')); ?>" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-solid fa-box-open"></i> View Applications
                    </li>
                </a>
                <a href="<?php echo e(route('client.show')); ?>" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-solid fa-chart-pie"></i> Reports
                    </li>
                </a>
            <?php elseif(Auth::user()->role_id === $admin): ?>
                <a href="<?php echo e(route('admin.users')); ?>" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-solid fa-users-cog"></i> Manage Users
                    </li>
                </a>
                <a href="<?php echo e(route('admin.denominations')); ?>" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-solid fa-cogs"></i> Manage Denominations
                    </li>
                </a>
                <a href="#" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-regular fa-envelope"></i> Manage Application Type
                    </li>
                </a>
                <a href="<?php echo e(route('admin.report')); ?>" class="text-decoration-none">
                    <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                        <i class="fa-solid fa-cogs"></i> Reports
                    </li>
                </a>
            <?php endif; ?>
        </ul>
    </div>

    <!-- Dynamic Content Area -->
    <div class="col-10">
        <div class="row gx-0 justify-content-start mt-3 ms-2">
            <?php if(Auth::user()->role_id === $client): ?>
                <div class="col-md-6 col-xl-4">
                    <div class="card p-5 m-2 card-background h-100 shadow-lg rounded">
                        <i class="fa-solid fa-file-upload d-block fs-1 text-primary text-center"></i>
                        <h3 class="text-center h4 mb-3">
                            <i class="fa-solid fa-file-circle-plus me-2"></i> File Application
                        </h3>
                        <p class="text-dark text-center">Submit your application details. Upload required files and submit.</p>
                    </div>
                </div>
                <div class="col-md-6 col-xl-4">
                    <div class="card p-5 m-2 card-background h-100 shadow-lg rounded">
                        <i class="fa-solid fa-clipboard-list d-block fs-1 text-primary text-center"></i>
                        <h3 class="text-center h4 mb-3">
                            <i class="fa-solid fa-clipboard-list me-2"></i> All Applications (<?php echo e($user->applications->count()); ?>)
                        </h3>
                        <p class="text-dark text-center">View all your previous applications and their status.</p>
                    </div>
                </div>
            <?php elseif(Auth::user()->role_id === $tech): ?>
                <div class="col-md-4 col-xl-4">
                    <div class="card p-5 m-2 card-background h-100 shadow-lg rounded">
                        <h3 class="text-center h4 mb-3">
                            <i class="fa-solid fa-users me-2"></i> All Applications (<?php echo e($applications->count()); ?>)
                        </h3>
                        <p class="text-dark text-center">Review and process all submitted applications from clients.</p>
                    </div>
                </div>
                <div class="col-md-4 col-xl-4">
                    <div class="card p-5 m-2 card-background h-100 shadow-lg rounded">
                        <h3 class="text-center h4 mb-3">
                            <i class="fa-solid fa-hourglass-half me-2"></i> Pending Application
                        </h3>
                        <p class="text-dark text-center">Check the applications that are awaiting review or action.</p>
                    </div>
                </div>
                <div class="col-md-4 col-xl-4">
                    <div class="card p-5 m-2 card-background h-100 shadow-lg rounded">
                        <h3 class="text-center h4 mb-3">
                            <i class="fa-solid fa-check-circle me-2"></i> Approved Application
                        </h3>
                        <p class="text-dark text-center">View and manage applications that have been approved.</p>
                    </div>
                </div>
            <?php elseif(Auth::user()->role_id === $admin): ?>
                <div class="col-md-4 col-xl-3">
                    <div class="card p-5 m-2 card-background h-100 shadow-lg rounded">
                        <i class="fa-solid fa-users d-block fs-1 text-primary text-center"></i>
                        <h3 class="text-center h4 mb-3">All Users (<?php echo e($all_users->count()); ?>)</h3>
                    </div>
                </div>
                <div class="col-md-4 col-xl-3">
                    <div class="card p-5 m-2 card-background h-100 shadow-lg rounded">
                        <i class="fa-solid fa-boxes d-block fs-1 text-primary text-center"></i>
                        <h3 class="text-center h4 mb-3">Denominations</h3>
                    </div>
                </div>
                <div class="col-md-4 col-xl-3">
                    <div class="card p-5 m-2 card-background h-100 shadow-lg rounded">
                        <i class="fa-regular fa-folder d-block fs-1 text-primary text-center"></i>
                        <h3 class="text-center h4 mb-3">Application Types</h3>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/ltfrb/resources/views/users/dashboard.blade.php ENDPATH**/ ?>