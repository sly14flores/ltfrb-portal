

<?php $__env->startSection('title', 'Denominations'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.denominations.store')); ?>" method="post">
    <?php echo csrf_field(); ?>

    <div class="row gx-2 mb-4">
        <div class="col-4">
            <input type="text" name="name" class="form-control" placeholder="Add a denomination..." autofocus>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add</button>
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</form>

<div class="row">
    <div class="col-7">
        <table class="table table-hover align-middle bg-white border table-sm text-center">
            <thead class="small table-warning">
                <th>#</th>
                <th>NAME</th>
                <th>COUNT</th>
                <th>LAST UPDATED</th>
                <th></th>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $all_denominations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denomination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($denomination->id); ?></td>
                        <td><?php echo e($denomination->name); ?></td>
                        <td><?php echo e($denomination->updated_at); ?></td>
                        <td>
                            
                            <button class="btn btn-outline-warning btn-sm me-2" data-bs-toggle="modal" data-bs-target="#edit-denomination-<?php echo e($denomination->id); ?>" title="Edit">
                                <i class="fa-solid fa-pen"></i>
                            </button>

                            
                            <button class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#delete-denomination-<?php echo e($denomination->id); ?>" title="Delete">
                                <i class="fa-solid fa-trash-can"></i>
                            </button>
                        </td>
                    </tr>
                    
                    <?php echo $__env->make('admin.denominations.modals.action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="lead text-muted text-center">No denominations found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mit-laravel\online-app\resources\views/admin/denominations/index.blade.php ENDPATH**/ ?>