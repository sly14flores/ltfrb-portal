

<?php $__env->startSection('title', 'Technical'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gx-0">
    <div class="col-2 admin-dashboard-list mh-100">
        <ul class="admin-list fs-5 list-group">
            <a href="<?php echo e(route('dashboard.index')); ?>" class="text-decoration-none text-white mb-1">
                <li class="fw-bold">
                    <i class="fa-solid fa-chart-line"></i> Dashboard
                </li>
            </a>
            <a href="<?php echo e(route('technical.show')); ?>" class="text-decoration-none text-white mb-1">
                <li class="fw-bold">
                    <i class="fa-solid fa-chart-line"></i> View Applications
                </li>
            </a>
            <a href="#" class="text-decoration-none text-white">
                <li class=" fw-bold text-white">
                    <i class="fa-regular fa-envelope"></i> Reports
                </li>
            </a>
        </ul>
    </div> 

    <div class="col-10 w-50 mx-auto">
        <div class="row mt-5">
            <div class="col bg-white">
                <h1 class="h3 mt-3">Full Name: <?php echo e($application->user->first_name); ?> <?php echo e($application->user->last_name); ?></h1>
    
                <p class="text-muted">Application Number: <?php echo e($application->app_number); ?></h3>
                    <hr>
                <div class="row">
                    <div class="col-6"> <h3>Penalties</h3></div>
                    <div class="col-6"><p class="h3">Amount</p></div>
                </div> 

                <form action="<?php echo e(route('technical.saveFees')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="app_id" value="<?php echo e($application->id); ?>">
                    <?php $__currentLoopData = $all_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-6"> 
                                <div class="form-check">
                                <label for="fees-<?php echo e($fee->id); ?>" class="form-check-label"><?php echo e($fee->name); ?></label>
                                <?php if($fee->id < 7): ?>
                                    <input type="checkbox" name="fees[<?php echo e($fee->id); ?>]" id="<?php echo e($fee->name); ?>" class="form-check-input" value=<?php echo e($fee->id); ?>>
                                <?php else: ?>
                                    <input type="number" name="custome_fees[<?php echo e($fee->id); ?>]" id="<?php echo e($fee->name); ?>" class="form-control">
                                <?php endif; ?>
                            </div>
                            <?php $__errorArgs = ['fees[<?php echo e($fee->id); ?>]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger small"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6">
                            <p class="text-muted"><?php echo e($fee->id > 6 ? '' : '₱'); ?> <?php echo e($fee->amount); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="row">
                        <div class="col-6">
                            <label for="surchages" class="form-label small">Surchages</label>
                            <input type="number" name="surcharges" id="surcharges" class="form-control">
                            <?php $__errorArgs = ['surcharges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger small"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-6">
                            <label for="late_confirmation" class="form-label small">Late Confirmation</label>
                            <input type="number" name="late_confirmation" id="late_confirmation" class="form-control">
                            <?php $__errorArgs = ['late_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger small"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        </div>
     

                    <div class="row">
                        <div class="col-6">
                            <label for="penalties" class="form-label small">Penalties</label>

                            <input type="number" name="penalties" id="penalties" class="form-control">
                        </div>
                        <?php $__errorArgs = ['penalties'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger small"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="col-6">
                                 
                            <label for="others" class="form-label small">Others</label>

                            <input type="number" name="others" id="others" class="form-control">
                        </div>
                        <?php $__errorArgs = ['others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger small"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div>

                    <div class="d-flex justify-content-between align-items-center my-3 me-5">
                        <button class="btn btn-primary ms-auto" type="submit">Submit</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-laravel-mit\online-app\resources\views/users/technical/fees.blade.php ENDPATH**/ ?>