

<?php $__env->startSection('title', 'View Application'); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-3"> <!-- Added spacing wrapper -->

<div class="row gx-0">
    <div class="card col-2 card-background h-100 shadow-lg rounded">
        <ul class="list-group sidebar-list fs-5">
            <a href="<?php echo e(route('client.create')); ?>" class="text-decoration-none">
                <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                    <i class="fa-solid fa-file-circle-plus"></i> File Application
                </li>
            </a>
            <a href="<?php echo e(route('client.show')); ?>" class="text-decoration-none">
                <li class="list-item fw-bold p-3 hover:bg-primary rounded text-white">
                    <i class="fa-regular fa-folder-open"></i> View Applications
                </li>
            </a>
        </ul>
    </div>

    <div class="col-10">
        <div class="row mt-4 mb-4">
            <div class="col">
                <h1 class="text-white text-center">View Application</h1>
            </div>
        </div>

        <table class="table table-striped w-75 mx-auto">
            <thead>
                <tr>
                    <th>ID No.</th>
                    <th>Application No.</th>
                    <th>Fees</th>
                    <th>Status</th>
                    <th>Remarks</th>
                    <th>Requirements</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $user->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($app->id); ?></td>
                    <td>
                        <button type="button" data-bs-toggle="modal" data-bs-target="#app-<?php echo e($app->id); ?>" class="btn bg-transparent text-primary">
                            <?php echo e($app->app_number); ?>

                        </button>
                    </td>
                    <td>
                        <a href="<?php echo e(route('client.showFees', $app->id)); ?>" class="text-decoration-none">
                            Show Fees
                        </a>
                    </td>
                    <td>
                        <?php if($app->status == 1): ?>
                            <span class="form-span text-success fst-italic">Verified</span>
                        <?php else: ?>
                            <span class="form-span text-warning fst-italic">Pending</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($app->remarks): ?>
                            <?php echo e($app->remarks); ?>        
                        <?php else: ?>
                            <span class="text-muted fst-italic">No remarks</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button type="button" data-bs-target="#requirements-<?php echo e($app->id); ?>" data-bs-toggle="modal" class="btn btn-sm bg-transparent text-primary">Requirements</button>
                    </td>
                </tr>
                <?php echo $__env->make('users.clients.modals.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">
                        <p class="text-muted fst-italic fs-2">No results found.</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</div> <!-- End spacing wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\online-appp\resources\views/users/clients/show.blade.php ENDPATH**/ ?>