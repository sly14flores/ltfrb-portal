

<?php $__env->startSection('title', 'View Application'); ?>

<?php $__env->startSection('content'); ?>


<div class="row gx-0">
    <div class="col-2 admin-dashboard-list mh-100   ">
        <ul class="admin-list fs-5 list-group">
            <a href="<?php echo e(route('client.create')); ?>" class="text-decoration-none text-white mb-1">
                <li class="fw-bold">
                    <i class="fa-solid fa-chart-line"></i> File Application
                </li>
            </a>
            <a href="<?php echo e(route('client.show')); ?>" class="text-decoration-none text-white">
                <li class=" fw-bold text-white">
                    <i class="fa-regular fa-envelope"></i> View Applications
                </li>
            </a>
        </ul>
    </div> 

    <div class="col-10">
        <div class="row mt-4 mb-4">
            <div class="col">
                <h1 class="text-white text-center">File Application</h1>
            </div>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID No.</th>
                    <th>Application No.</th>
                    <th>Application Type</th>
                    <th>Denomination</th>
                    <th>Chassis No.</th>
                    <th>Motor No.</th>
                    <th>Plate No.</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $user->applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($app->id); ?></td>
                    <td>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            <?php echo e($app->app_number); ?>

                        </a>
                    </td>
                    <td><?php echo e($app->type->name); ?></td>
                    
                    <td><?php echo e($app->deno->name); ?></td>
                    <td><?php echo e($app->chassis_number); ?></td>
                    <td><?php echo e($app->motor_number); ?></td>
                    <td><?php echo e($app->plate_number); ?></td>
                    
                    <td>
                        <form action="#" method="post">
                            
                            <?php if(Auth::user()->id !== 4): ?>
                                <input type="checkbox" name="verify" id="verify" class="form-check-input" disabled>
                                <label for="verify" class="form-label text-success fst-italic">Verified</label>
                            <?php else: ?>
                                <input type="checkbox" name="verify" id="verify" class="form-check-input">
                                <label for="verify" class="form-label text-success fst-italic">Verified</label>
                            <?php endif; ?>
                           
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">
                        <p class="text-muted fst-italic fs-2">No results found.</p>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
    <div class="modal-header">
    <h1 class="modal-title fs-5" id="staticBackdropLabel">Application Status</h1>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <div class="progress" role="progressbar" aria-label="Example with label" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
            <div class="progress-bar" style="width: 25%">25%</div>
        </div>
        <p> Checking </p>
        <hr>
        Note:
            There is no note!
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <button type="button" class="btn btn-primary">OK</button>
    </div>
</div>
</div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-laravel-mit\online-app\resources\views/users/home.blade.php ENDPATH**/ ?>