

<?php $__env->startSection('title', 'File Application'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gx-0">
    <div class="col-2 admin-dashboard-list mh-100   ">
        <ul class="admin-list fs-5 list-group">
            <a href="<?php echo e(route('client.create')); ?>" class="text-decoration-none text-white mb-1">
                <li class="fw-bold">
                    <i class="fa-solid fa-chart-line"></i> File Application
                </li>
            </a>
            <a href="<?php echo e(route('client.show')); ?>" class="text-decoration-none text-white">
                <li class=" fw-bold text-white">
                    <i class="fa-regular fa-envelope"></i> View Applications
                </li>
            </a>
        </ul>
    </div> 

<div class="col-10">
    <main class=" w-90 m-auto border rounded text-start mx-1 my-1">
        <form action="<?php echo e(route('application.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h1 class="h2 mb-1 fw-normal" style="font-family:helvetica;">File Application</h1>
            <div class="col">
                <select name="app_type" id="app-type" class="form-select form-select-lg">
                    <option value="" hidden>Select Application Type</option>
                    <?php $__currentLoopData = $all_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__errorArgs = ['app_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger small"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col mt-1">
                <select name="denomination" id="denomination" class="form-select form-select-lg">
                    <option value="" hidden>Select Denomination</option>
                    <?php $__currentLoopData = $all_denominations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denomination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($denomination->id); ?>"><?php echo e($denomination->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['denomination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger small"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="input-group input-group-sm form-floating">
                <div class="form-floating mt-1">
                    <input type="text" name="case_no" id="case-no" placeholder="Case No." class="form-control form-control-lg">
                    <label for="case-no">Case No.</label>
                    <?php $__errorArgs = ['case_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger small"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mt-1">
                    <input type="text" name="motor_no" id="motor-no" placeholder="Motor No." class="form-control form-control-lg">
                    <label for="motor-no">Motor No.</label>
                    <?php $__errorArgs = ['motor_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger small"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="input-group input-group-sm form-floating">
                <div class="form-floating mt-1">
                    <input type="text" name="chassis_no" id="chassis-no" placeholder="Chassis No." class="form-control form-control-lg">
                    <label for="chassis-no">Chasis Number</label>
                    <?php $__errorArgs = ['chassis_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger small"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-floating mt-1">
                    <input type="text" name="plate_number" id="plate-number" placeholder="Plate Number" class="form-control form-control-lg">
                    <label for="plate-number">Plate Number</label>
                    <?php $__errorArgs = ['plate_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger small"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="text-center">
                <button class="btn btn-primary btn-lg mx-1 my-1" type="submit"><?php echo e(__('Submit')); ?></button>
                <button class="btn btn-secondary btn-lg my-1" type="submit"><?php echo e(__('Clear')); ?></button>
            </div>
        </form>
    </main>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-laravel-mit\online-app\resources\views/users/clients/create.blade.php ENDPATH**/ ?>