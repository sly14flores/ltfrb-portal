<?php $__env->startSection('content'); ?>

<div class="row gx-0">
    <div class="col-3 admin-dashboard-list">
        <ul class="admin-list fs-3">
            <li class="p-3 fw-bold">
                <a href="#" class="text-decoration-none mb-2 text-white">
                    <i class="fa-solid fa-chart-line"></i> &nbsp;&nbsp;&nbsp; Dashboard
                </a>
            </li>

            <li class="p-3 fw-bold text-white">
                <a href="#" class="text-decoration-none mb-2 text-white">
                    <i class="fa-regular fa-envelope"></i> &nbsp;&nbsp;&nbsp; View Applications
                </a>
            </li>

            <li class="p-3 fw-bold text-white">
                <a href="#" class="text-decoration-none mb-2 text-white">
                    <i class="fa-regular fa-image"></i> &nbsp;&nbsp;&nbsp; Reports
                </a>
            </li>
        </ul>
    </div> 

    <div class="col-9">
        <div class="row gx-0">
            <div class="col">
                <div class="card p-5 m-2 ms-4 card-background h-100">
                    <i class="fa-solid fa-car d-block fs-1 text-primary text-center"></i>
                    <h3 class="text-center">
                        <strong>0</strong> Units
                    </h3>
                    <p class="text-dark text-center">Describe the item here. Include important features, pricing and relevant info.</p>
                </div>
            </div>
            <div class="col">
                <div class="card p-5 m-2 card-background h-100">
                    <i class="fa-solid fa-user d-block fs-1 text-primary text-center"></i>
                    <h3 class="text-center">
                        Coop/Operator
                    </h3>
                    <p class="text-dark text-center">Describe the item here. Include important features, pricing and relevant info.</p>
                </div>
            </div>
            <div class="col">
                <div class="card p-5 m-2 card-background h-100">
                    <i class="fa-regular fa-folder d-block fs-1 text-primary text-center"></i>
                    <h3 class="text-center">
                        Application
                    </h3>
                    <p class="text-dark text-center">Describe the item here. Include important features, pricing and relevant info.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mit-laravel\online-app\resources\views/home.blade.php ENDPATH**/ ?>