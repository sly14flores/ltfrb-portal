<?php $__env->startSection('content'); ?>
<style>
    label {
        color: #fff;
    }
</style>
    <main class="form-signin w-100 m-auto border rounded text-center">
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <img src="<?php echo e(asset('icons/ltfrb_seal.png')); ?>" alt="LTFRB SEAL" width="60" height="60">
            <h1 class="h2 mb-1 fw-normal" style="font-family:helvetica;">Create account</h1>

            <div class="input-group input-group-sm form-floating">
                <div class="form-floating mt-1">
                    <input type="text" class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name" value="<?php echo e(old('first_name')); ?>" required autocomplete="first-name" id="first-name" name="first-name" placeholder="First Name">
                    <label for="first-name">First Name</label>
                
                </div>
                <div class="form-floating mt-1">
                    <input id="last-name" type="text" class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name" value="<?php echo e(old('last_name')); ?>" required autocomplete="last-name" placeholder="Last Name">
                    <label for="last-name">Last Name</label>
                </div>
            </div>
            <div class="form-floating mt-1">
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="mail@mail.com" required autocomplete="email">
                <label for="email">Email address</label>
            </div>
            <div class="form-floating mt-1">
                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Password" required autocomplete="new-password">
                <label for="password">Password</label>
            </div>
            <div class="form-floating mt-1">
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Confirm Password">
                <label for="password-confirm">Confirm Password</label>
            </div>
            <button class="btn btn-primary w-100 " type="submit"><?php echo e(__('Register')); ?></button>
            <p class=""> 
                Already have an account? 
                <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Sign in')); ?></a> 
            </p>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mit-laravel\online-app\resources\views/auth/register.blade.php ENDPATH**/ ?>