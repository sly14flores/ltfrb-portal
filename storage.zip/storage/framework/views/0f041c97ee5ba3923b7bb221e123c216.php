

<?php $__env->startSection('title', 'Show Fees'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gx-0">
    <div class="col-2 admin-dashboard-list mh-100   ">
        <ul class="admin-list fs-5 list-group">
            <a href="<?php echo e(route('client.create')); ?>" class="text-decoration-none text-white mb-1">
                <li class="fw-bold">
                    <i class="fa-solid fa-chart-line"></i> File Application
                </li>
            </a>
            <a href="<?php echo e(route('client.show')); ?>" class="text-decoration-none text-white">
                <li class=" fw-bold text-white">
                    <i class="fa-regular fa-envelope"></i> View Applications
                </li>
            </a>
        </ul>
    </div> 

    <div class="col-10 w-50 mx-auto">
        <div class="row mt-5">
            <div class="col bg-white">
                <h1 class="h3 mt-3">Full Name: <?php echo e($application->user->first_name); ?> <?php echo e($application->user->last_name); ?></h1>
    
                
                <hr>

                <div class="row">
                    <div class="col-6"><h3>Penalties</h3></div>
                    <div class="col-6"><p class="h3">Amount</p></div>
                </div> 

                <div class="row my-3">
                    <div class="col-6">
                        <?php $__currentLoopData = $application->applicationFees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application_fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($application_fee->fee->name); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($application->surcharges == 0 && $application->late_confirmation == 0 &&$application->penalties == 0 && $application->others == 0): ?>

                        <?php else: ?>
                            <p>Surchages</p>
                            <p>Late Confirmation</p>
                            <p>Penalties</p>
                            <p>Others</p>
                        <?php endif; ?>
                        
                    </div>

                    <div class="col-6">
                        <?php $__currentLoopData = $application->applicationFees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application_fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p>₱ <?php echo e($application_fee->fee->amount); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($application->surcharges == 0 && $application->late_confirmation == 0 &&$application->penalties == 0 && $application->others == 0): ?>
                           
                        <?php else: ?>
                            <p>₱ <?php echo e($application->surcharges); ?></p>
                            <p>₱ <?php echo e($application->late_confirmation); ?></p>
                            <p>₱ <?php echo e($application->penalties); ?></p>
                            <p>₱ <?php echo e($application->others); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mt-1 mb-0">
                    <div class="col-6">
                        <p class="fw-bold fs-2">Total</p>
                    </div>

                    <div class="col-6">
                        <p class="fs-2">₱ <?php echo e($total); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-laravel-mit\online-app\resources\views/users/clients/fees.blade.php ENDPATH**/ ?>