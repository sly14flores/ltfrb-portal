

<?php $__env->startSection('title', 'Show Fees'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gx-0">
    <div class="col-2 admin-dashboard-list mh-100">
        <ul class="admin-list fs-5 list-group">
            <a href="<?php echo e(route('dashboard.index')); ?>" class="text-decoration-none text-white mb-1">
                <li class="fw-bold">
                    <i class="fa-solid fa-chart-line"></i> Dashboard
                </li>
            </a>
            <a href="<?php echo e(route('technical.show')); ?>" class="text-decoration-none text-white mb-1">
                <li class="fw-bold">
                    <i class="fa-solid fa-chart-line"></i> View Applications
                </li>
            </a>
            <a href="#" class="text-decoration-none text-white">
                <li class=" fw-bold text-white">
                    <i class="fa-regular fa-envelope"></i> Reports
                </li>
            </a>
        </ul>
    </div> 

    <div class="col-10 w-50 mx-auto">
        <div class="row mt-5">
            <div class="col bg-white">
                <h1 class="h3 mt-3">Full Name: <?php echo e($application->user->first_name); ?> <?php echo e($application->user->last_name); ?></h1>
                
                <a href="<?php echo e(route('technical.fees', $application->id)); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Add Fees
                </a>
                
                <hr>
                
                <table class="table table-hover align-middle">
                    <thead>
                        <th>Penalties</th>
                        <th>Amount</th>
                        <th></th>
                    </thead>
                    <tbody>
                   
                        <?php $__currentLoopData = $application->applicationFees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application_fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($application_fee->fee->name); ?></td>
                            <td><?php echo e($application_fee->fee->amount); ?></td>
                            <td>
                                <form action="<?php echo e(route('technical.deletefees', $application_fee->application_id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" name="fee_id" class="btn btn-danger btn-sm" value="<?php echo e($application_fee->fee_id); ?>">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($application->surcharges == 0 && $application->late_confirmation == 0 &&$application->penalties == 0 && $application->others == 0): ?>
                            <tr>
                                <td class="fst-italic text-secondary" colspan="3">No other fees (Surcharges, Late Confirmation, Penalties, Others).</td>
                            </tr>   
                        <?php else: ?>

                            <?php if($application->surcharges == null): ?>
                    
                            <?php else: ?>
                            <td>Surcharges</td>
                            <td><?php echo e($application->surcharges); ?></td>
                            <td>
                                <form action="<?php echo e(route('technical.deleteSurcharges', $application->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fas fa-minus"></i>
                                    </button>
                                </form>
                            </td>
                            <?php endif; ?>

                            </tr>

                            <?php if($application->late_confirmation == null): ?>

                            <?php else: ?>
                            <tr>
                                <td>Late Confirmation</td>
                                <td><?php echo e($application->late_confirmation); ?></td>
                                <td>
                                    <form action="<?php echo e(route('technical.deleteLateConfirmation', $application->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endif; ?>

                            <?php if($application->penalties == null): ?>

                            <?php else: ?>
                            <tr>
                                <td>Penalties</td>
                                <td><?php echo e($application->penalties); ?></td>
                                <td>
                                    <form action="<?php echo e(route('technical.deletePenalties', $application->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endif; ?>

                            <?php if($application->others == null): ?>

                            <?php else: ?>
                            <tr>
                                <td>Others</td>
                                <td><?php echo e($application->others); ?></td>
                                <td>
                                    <form action="<?php echo e(route('technical.deleteOthers', $application->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <tr>
                            <td class="fw-bold">Total</td>
                            <td><?php echo e($total_fees); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-laravel-mit\online-app\resources\views/users/technical/showfees.blade.php ENDPATH**/ ?>